<?php
/**
 * Admin Menu Registration
 *
 * Registers the top-level "Wholesale" menu and its sub-pages:
 *  - Applications  (wholesale_pending users)
 *  - Approved Customers (wholesale_customer users)
 *
 * @package WholesaleAdminManager
 */

defined( 'ABSPATH' ) || exit;

/**
 * Register top-level menu and sub-menus.
 *
 * Hooked to 'admin_menu' in the main plugin file.
 */
function wam_register_admin_menu(): void {

	/*
	 * Top-level menu — points directly to the Applications page.
	 */
	add_menu_page(
		__( 'Wholesale', 'wholesale-admin-manager' ),   // Page title
		__( 'Wholesale', 'wholesale-admin-manager' ),   // Menu label
		'manage_woocommerce',                           // Capability required
		'wholesale-applications',                       // Menu slug
		'wam_render_applications_page',                 // Callback
		'dashicons-groups',                             // Icon
		56                                              // Position (after WooCommerce ~55)
	);

	/*
	 * Sub-page 1: Applications (mirrors the top-level entry so the first item
	 * label reads "Applications" instead of the duplicated "Wholesale").
	 */
	add_submenu_page(
		'wholesale-applications',
		__( 'Wholesale Applications', 'wholesale-admin-manager' ),
		__( 'Applications', 'wholesale-admin-manager' ),
		'manage_woocommerce',
		'wholesale-applications',
		'wam_render_applications_page'
	);

	/*
	 * Sub-page 2: Approved Customers
	 */
	add_submenu_page(
		'wholesale-applications',
		__( 'Approved Wholesale Customers', 'wholesale-admin-manager' ),
		__( 'Approved Customers', 'wholesale-admin-manager' ),
		'manage_woocommerce',
		'wholesale-customers',
		'wam_render_approved_customers_page'
	);
}
