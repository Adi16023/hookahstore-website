<?php
/**
 * Applications Page
 *
 * Renders the WordPress admin table listing all users with role
 * `wholesale_pending`. Supports search, filter, pagination, and
 * per-row Approve / Reject actions.
 *
 * @package WholesaleAdminManager
 */

defined( 'ABSPATH' ) || exit;

// ---------------------------------------------------------------------------
// Admin-notice renderer (lives here so it is printed at the top of the page)
// ---------------------------------------------------------------------------

/**
 * Display an inline admin notice based on the `wam_msg` query arg.
 */
function wam_maybe_show_notice(): void {
	if ( empty( $_GET['wam_msg'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		return;
	}

	$msg  = sanitize_text_field( wp_unslash( $_GET['wam_msg'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
	$type = 'updated';
	$text = '';

	switch ( $msg ) {
		case 'approved':
			$text = __( '✅ Application approved. The user has been granted wholesale access.', 'wholesale-admin-manager' );
			break;
		case 'rejected':
			$text = __( '❌ Application rejected. The user has been converted to a standard customer.', 'wholesale-admin-manager' );
			$type = 'notice-warning';
			break;
		case 'error':
			$text = __( '⚠️ An error occurred. The user may not exist or may not be a pending wholesale applicant.', 'wholesale-admin-manager' );
			$type = 'notice-error';
			break;
	}

	if ( $text ) {
		printf(
			'<div class="notice %s is-dismissible"><p>%s</p></div>',
			esc_attr( $type ),
			esc_html( $text )
		);
	}
}

// ---------------------------------------------------------------------------
// Main page render callback
// ---------------------------------------------------------------------------

/**
 * Render the Wholesale Applications admin page.
 *
 * Hooked via add_menu_page / add_submenu_page in admin-menu.php.
 */
function wam_render_applications_page(): void {

	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		wp_die( esc_html__( 'You do not have permission to view this page.', 'wholesale-admin-manager' ) );
	}

	// ------------------------------------------------------------------
	// Read GET parameters (no nonce needed — read-only query).
	// ------------------------------------------------------------------
	$search_email    = isset( $_GET['s'] )               ? sanitize_email( wp_unslash( $_GET['s'] ) )              : ''; // phpcs:ignore WordPress.Security.NonceVerification
	$filter_business = isset( $_GET['filter_business'] ) ? sanitize_text_field( wp_unslash( $_GET['filter_business'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	$filter_gst      = isset( $_GET['filter_gst'] )      ? sanitize_text_field( wp_unslash( $_GET['filter_gst'] ) )      : ''; // phpcs:ignore WordPress.Security.NonceVerification
	$current_page    = isset( $_GET['paged'] )            ? max( 1, absint( $_GET['paged'] ) )                            : 1;
	$per_page        = 20;

	// ------------------------------------------------------------------
	// WP_User_Query arguments.
	// ------------------------------------------------------------------
	$query_args = [
		'role'   => 'wholesale_pending',
		'number' => $per_page,
		'offset' => ( $current_page - 1 ) * $per_page,
		'orderby' => 'registered',
		'order'   => 'DESC',
	];

	// Email search.
	if ( $search_email ) {
		$query_args['search']         = '*' . $search_email . '*';
		$query_args['search_columns'] = [ 'user_email' ];
	}

	// Meta-based filters require a meta_query.
	$meta_query = [];

	if ( $filter_business ) {
		$meta_query[] = [
			'key'     => 'business_name',
			'value'   => $filter_business,
			'compare' => 'LIKE',
		];
	}

	if ( $filter_gst ) {
		$meta_query[] = [
			'key'     => 'gst_number',
			'value'   => $filter_gst,
			'compare' => 'LIKE',
		];
	}

	if ( ! empty( $meta_query ) ) {
		$query_args['meta_query'] = $meta_query; // phpcs:ignore WordPress.DB.SlowDBQuery
	}

	// Run total count query (without limit) for pagination.
	$count_args                  = $query_args;
	$count_args['number']        = -1;
	$count_args['offset']        = 0;
	$count_args['count_total']   = true;
	$count_query                 = new WP_User_Query( $count_args );
	$total_users                 = (int) $count_query->get_total();
	$total_pages                 = (int) ceil( $total_users / $per_page );

	// Main query.
	$user_query = new WP_User_Query( $query_args );
	$users      = $user_query->get_results();

	// ------------------------------------------------------------------
	// Render
	// ------------------------------------------------------------------
	?>
	<div class="wrap wam-wrap">

		<h1 class="wp-heading-inline">
			<?php esc_html_e( 'Wholesale Applications', 'wholesale-admin-manager' ); ?>
		</h1>

		<span class="wam-badge"><?php echo esc_html( $total_users ); ?></span>

		<?php wam_maybe_show_notice(); ?>

		<!-- ============================================================
		     FILTER / SEARCH FORM
		     ============================================================ -->
		<div class="wam-filters">
			<form method="get" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>">
				<input type="hidden" name="page" value="wholesale-applications" />

				<label class="screen-reader-text" for="wam-search-email">
					<?php esc_html_e( 'Search by Email', 'wholesale-admin-manager' ); ?>
				</label>
				<input
					type="email"
					id="wam-search-email"
					name="s"
					class="wam-filter-input"
					placeholder="<?php esc_attr_e( 'Search by email…', 'wholesale-admin-manager' ); ?>"
					value="<?php echo esc_attr( $search_email ); ?>"
				/>

				<label class="screen-reader-text" for="wam-filter-business">
					<?php esc_html_e( 'Filter by Business Name', 'wholesale-admin-manager' ); ?>
				</label>
				<input
					type="text"
					id="wam-filter-business"
					name="filter_business"
					class="wam-filter-input"
					placeholder="<?php esc_attr_e( 'Filter by business name…', 'wholesale-admin-manager' ); ?>"
					value="<?php echo esc_attr( $filter_business ); ?>"
				/>

				<label class="screen-reader-text" for="wam-filter-gst">
					<?php esc_html_e( 'Filter by GST Number', 'wholesale-admin-manager' ); ?>
				</label>
				<input
					type="text"
					id="wam-filter-gst"
					name="filter_gst"
					class="wam-filter-input"
					placeholder="<?php esc_attr_e( 'Filter by GST number…', 'wholesale-admin-manager' ); ?>"
					value="<?php echo esc_attr( $filter_gst ); ?>"
				/>

				<?php submit_button( __( 'Filter', 'wholesale-admin-manager' ), 'secondary', 'submit', false ); ?>

				<?php if ( $search_email || $filter_business || $filter_gst ) : ?>
					<a
						href="<?php echo esc_url( admin_url( 'admin.php?page=wholesale-applications' ) ); ?>"
						class="button"
					><?php esc_html_e( 'Reset', 'wholesale-admin-manager' ); ?></a>
				<?php endif; ?>
			</form>
		</div>

		<!-- ============================================================
		     APPLICATIONS TABLE
		     ============================================================ -->
		<table class="wp-list-table widefat fixed striped wam-table">
			<thead>
				<tr>
					<th scope="col" class="column-id"><?php esc_html_e( 'Application ID', 'wholesale-admin-manager' ); ?></th>
					<th scope="col" class="column-name"><?php esc_html_e( 'Name', 'wholesale-admin-manager' ); ?></th>
					<th scope="col" class="column-email"><?php esc_html_e( 'Email', 'wholesale-admin-manager' ); ?></th>
					<th scope="col" class="column-business"><?php esc_html_e( 'Business Name', 'wholesale-admin-manager' ); ?></th>
					<th scope="col" class="column-address"><?php esc_html_e( 'Business Address', 'wholesale-admin-manager' ); ?></th>
					<th scope="col" class="column-phone"><?php esc_html_e( 'Phone', 'wholesale-admin-manager' ); ?></th>
					<th scope="col" class="column-gst"><?php esc_html_e( 'GST Number', 'wholesale-admin-manager' ); ?></th>
					<th scope="col" class="column-website"><?php esc_html_e( 'Website', 'wholesale-admin-manager' ); ?></th>
					<th scope="col" class="column-docs"><?php esc_html_e( 'Documents', 'wholesale-admin-manager' ); ?></th>
					<th scope="col" class="column-date"><?php esc_html_e( 'Submitted Date', 'wholesale-admin-manager' ); ?></th>
					<th scope="col" class="column-actions"><?php esc_html_e( 'Actions', 'wholesale-admin-manager' ); ?></th>
				</tr>
			</thead>
			<tbody>
			<?php if ( empty( $users ) ) : ?>
				<tr>
					<td colspan="11" class="wam-empty">
						<?php esc_html_e( 'No pending wholesale applications found.', 'wholesale-admin-manager' ); ?>
					</td>
				</tr>
			<?php else : ?>
				<?php foreach ( $users as $user ) : ?>
					<?php
					$user_id = (int) $user->ID;
					$meta    = array_map(
						fn( $v ) => $v[0] ?? '',
						get_user_meta( $user_id )
					);

					// Helper to safely pull from flat meta map.
					$m = fn( string $key ): string => isset( $meta[ $key ] ) ? (string) $meta[ $key ] : '';

					$business_name    = $m( 'business_name' );
					$business_address = $m( 'business_address' );
					$business_phone   = $m( 'business_phone' );
					$gst_number       = $m( 'gst_number' );
					$business_website = $m( 'business_website' );

					// Document URLs.
					$gst_cert_url  = $m( 'gst_certificate_url' );
					$license_url   = $m( 'business_license_url' );
					$identity_url  = $m( 'identity_document_url' );

					$submitted_date = $user->user_registered
						? wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $user->user_registered ) )
						: '—';
					?>
					<tr>
						<!-- Application ID -->
						<td class="column-id">
							<strong><?php echo esc_html( '#' . $user_id ); ?></strong>
						</td>

						<!-- Name -->
						<td class="column-name">
							<a href="<?php echo esc_url( get_edit_user_link( $user_id ) ); ?>">
								<?php echo esc_html( $user->display_name ); ?>
							</a>
						</td>

						<!-- Email -->
						<td class="column-email">
							<a href="mailto:<?php echo esc_attr( $user->user_email ); ?>">
								<?php echo esc_html( $user->user_email ); ?>
							</a>
						</td>

						<!-- Business Name -->
						<td class="column-business"><?php echo esc_html( $business_name ?: '—' ); ?></td>

						<!-- Business Address -->
						<td class="column-address"><?php echo esc_html( $business_address ?: '—' ); ?></td>

						<!-- Phone -->
						<td class="column-phone"><?php echo esc_html( $business_phone ?: '—' ); ?></td>

						<!-- GST Number -->
						<td class="column-gst">
							<code><?php echo esc_html( $gst_number ?: '—' ); ?></code>
						</td>

						<!-- Website -->
						<td class="column-website">
							<?php if ( $business_website ) : ?>
								<a href="<?php echo esc_url( $business_website ); ?>" target="_blank" rel="noopener noreferrer">
									<?php echo esc_html( $business_website ); ?>
								</a>
							<?php else : ?>
								—
							<?php endif; ?>
						</td>

						<!-- Documents -->
						<td class="column-docs">
							<div class="wam-docs">
								<?php if ( $gst_cert_url ) : ?>
									<a href="<?php echo esc_url( $gst_cert_url ); ?>" target="_blank" rel="noopener noreferrer" class="wam-doc-link wam-doc-gst">
										<?php esc_html_e( 'View GST Certificate', 'wholesale-admin-manager' ); ?>
									</a>
								<?php endif; ?>

								<?php if ( $license_url ) : ?>
									<a href="<?php echo esc_url( $license_url ); ?>" target="_blank" rel="noopener noreferrer" class="wam-doc-link wam-doc-license">
										<?php esc_html_e( 'View Business License', 'wholesale-admin-manager' ); ?>
									</a>
								<?php endif; ?>

								<?php if ( $identity_url ) : ?>
									<a href="<?php echo esc_url( $identity_url ); ?>" target="_blank" rel="noopener noreferrer" class="wam-doc-link wam-doc-identity">
										<?php esc_html_e( 'View Identity Document', 'wholesale-admin-manager' ); ?>
									</a>
								<?php endif; ?>

								<?php if ( ! $gst_cert_url && ! $license_url && ! $identity_url ) : ?>
									<span class="wam-no-docs"><?php esc_html_e( 'No documents', 'wholesale-admin-manager' ); ?></span>
								<?php endif; ?>
							</div>
						</td>

						<!-- Submitted Date -->
						<td class="column-date">
							<span title="<?php echo esc_attr( $user->user_registered ); ?>">
								<?php echo esc_html( $submitted_date ); ?>
							</span>
						</td>

						<!-- Actions -->
						<td class="column-actions">
							<div class="wam-actions">

								<!-- Approve form -->
								<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="wam-action-form">
									<input type="hidden" name="action"  value="approve_wholesale_user" />
									<input type="hidden" name="user_id" value="<?php echo esc_attr( $user_id ); ?>" />
									<?php wp_nonce_field( 'approve_wholesale_user', 'wam_nonce' ); ?>
									<button
										type="submit"
										class="button button-primary wam-btn-approve"
										onclick="return confirm('<?php echo esc_js( __( 'Approve this wholesale application?', 'wholesale-admin-manager' ) ); ?>')"
									>
										<?php esc_html_e( 'Approve', 'wholesale-admin-manager' ); ?>
									</button>
								</form>

								<!-- Reject form -->
								<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="wam-action-form">
									<input type="hidden" name="action"  value="reject_wholesale_user" />
									<input type="hidden" name="user_id" value="<?php echo esc_attr( $user_id ); ?>" />
									<?php wp_nonce_field( 'reject_wholesale_user', 'wam_nonce' ); ?>
									<button
										type="submit"
										class="button wam-btn-reject"
										onclick="return confirm('<?php echo esc_js( __( 'Reject this wholesale application? The user will be converted to a standard customer.', 'wholesale-admin-manager' ) ); ?>')"
									>
										<?php esc_html_e( 'Reject', 'wholesale-admin-manager' ); ?>
									</button>
								</form>

							</div><!-- .wam-actions -->
						</td>
					</tr>
				<?php endforeach; ?>
			<?php endif; ?>
			</tbody>
			<tfoot>
				<tr>
					<th scope="col"><?php esc_html_e( 'Application ID', 'wholesale-admin-manager' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Name', 'wholesale-admin-manager' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Email', 'wholesale-admin-manager' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Business Name', 'wholesale-admin-manager' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Business Address', 'wholesale-admin-manager' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Phone', 'wholesale-admin-manager' ); ?></th>
					<th scope="col"><?php esc_html_e( 'GST Number', 'wholesale-admin-manager' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Website', 'wholesale-admin-manager' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Documents', 'wholesale-admin-manager' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Submitted Date', 'wholesale-admin-manager' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Actions', 'wholesale-admin-manager' ); ?></th>
				</tr>
			</tfoot>
		</table>

		<!-- ============================================================
		     PAGINATION
		     ============================================================ -->
		<?php if ( $total_pages > 1 ) : ?>
			<div class="tablenav bottom">
				<div class="tablenav-pages">
					<span class="displaying-num">
						<?php
						printf(
							/* translators: %d: total applications */
							esc_html( _n( '%d application', '%d applications', $total_users, 'wholesale-admin-manager' ) ),
							esc_html( number_format_i18n( $total_users ) )
						);
						?>
					</span>
					<span class="pagination-links">
						<?php
						$base_url = add_query_arg(
							[
								'page'            => 'wholesale-applications',
								's'               => $search_email,
								'filter_business' => $filter_business,
								'filter_gst'      => $filter_gst,
							],
							admin_url( 'admin.php' )
						);

						// First / Previous.
						if ( $current_page > 1 ) {
							printf(
								'<a class="first-page button" href="%s" title="%s">«</a>',
								esc_url( add_query_arg( 'paged', 1, $base_url ) ),
								esc_attr__( 'First page', 'wholesale-admin-manager' )
							);
							printf(
								'<a class="prev-page button" href="%s" title="%s">‹</a>',
								esc_url( add_query_arg( 'paged', max( 1, $current_page - 1 ), $base_url ) ),
								esc_attr__( 'Previous page', 'wholesale-admin-manager' )
							);
						}

						printf(
							'<span class="paging-input">%d / %d</span>',
							esc_html( $current_page ),
							esc_html( $total_pages )
						);

						// Next / Last.
						if ( $current_page < $total_pages ) {
							printf(
								'<a class="next-page button" href="%s" title="%s">›</a>',
								esc_url( add_query_arg( 'paged', min( $total_pages, $current_page + 1 ), $base_url ) ),
								esc_attr__( 'Next page', 'wholesale-admin-manager' )
							);
							printf(
								'<a class="last-page button" href="%s" title="%s">»</a>',
								esc_url( add_query_arg( 'paged', $total_pages, $base_url ) ),
								esc_attr__( 'Last page', 'wholesale-admin-manager' )
							);
						}
						?>
					</span>
				</div>
			</div>
		<?php endif; ?>

	</div><!-- .wrap -->
	<?php
}
