<?php
/**
 * Plugin Name:       Wholesale Admin Manager
 * Plugin URI:        https://github.com/your-repo/wholesale-admin-manager
 * Description:       Manage wholesale account applications from the WordPress admin. Review, approve, and reject wholesale applications submitted via the headless Next.js frontend.
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      8.0
 * Author:            Your Agency
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       wholesale-admin-manager
 * Domain Path:       /languages
 *
 * @package WholesaleAdminManager
 */

defined( 'ABSPATH' ) || exit;

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

define( 'WAM_VERSION',     '1.0.0' );
define( 'WAM_PLUGIN_FILE', __FILE__ );
define( 'WAM_PLUGIN_DIR',  plugin_dir_path( __FILE__ ) );
define( 'WAM_PLUGIN_URL',  plugin_dir_url( __FILE__ ) );

// ---------------------------------------------------------------------------
// Autoload includes
// ---------------------------------------------------------------------------

/**
 * Load all required include files.
 */
function wam_load_includes(): void {
	$files = [
		'includes/actions.php',
		'includes/admin-menu.php',
		'includes/applications-page.php',
		'includes/approved-customers-page.php',
	];

	foreach ( $files as $file ) {
		$path = WAM_PLUGIN_DIR . $file;
		if ( file_exists( $path ) ) {
			require_once $path;
		}
	}
}
wam_load_includes();

// ---------------------------------------------------------------------------
// Admin menu
// ---------------------------------------------------------------------------

add_action( 'admin_menu', 'wam_register_admin_menu' );

// ---------------------------------------------------------------------------
// Enqueue admin styles
// ---------------------------------------------------------------------------

/**
 * Enqueue plugin admin stylesheet only on plugin pages.
 */
add_action( 'admin_enqueue_scripts', function ( string $hook ): void {
	$allowed_hooks = [
		'toplevel_page_wholesale-applications',
		'wholesale_page_wholesale-customers',
	];

	if ( in_array( $hook, $allowed_hooks, true ) ) {
		wp_enqueue_style(
			'wholesale-admin-manager',
			WAM_PLUGIN_URL . 'assets/admin.css',
			[],
			WAM_VERSION
		);
	}
} );

// ---------------------------------------------------------------------------
// admin_post_ action handlers
// ---------------------------------------------------------------------------

add_action( 'admin_post_approve_wholesale_user', 'wam_handle_approve_user' );
add_action( 'admin_post_reject_wholesale_user',  'wam_handle_reject_user' );

// ---------------------------------------------------------------------------
// Activation hook
// ---------------------------------------------------------------------------

register_activation_hook( __FILE__, function (): void {
	// No database tables needed — all data lives in user meta.
	// Flush rewrite rules on activation just in case.
	flush_rewrite_rules();
} );

// ---------------------------------------------------------------------------
// Deactivation hook
// ---------------------------------------------------------------------------

register_deactivation_hook( __FILE__, function (): void {
	flush_rewrite_rules();
} );
