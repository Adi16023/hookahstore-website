<?php
/**
 * Action Handlers: Approve & Reject Wholesale Users
 *
 * These handlers listen on admin_post_ hooks registered in the main plugin file.
 * Both actions are protected with nonces and capability checks.
 *
 * @package WholesaleAdminManager
 */

defined( 'ABSPATH' ) || exit;

// ---------------------------------------------------------------------------
// Helper
// ---------------------------------------------------------------------------

/**
 * Build the redirect URL back to the Applications page, with an optional
 * admin-notice query argument.
 *
 * @param string $status  'approved' | 'rejected' | 'error'
 * @param int    $user_id The affected user ID (used for display / debugging).
 * @return string
 */
function wam_redirect_url( string $status, int $user_id = 0 ): string {
	return add_query_arg(
		[
			'page'    => 'wholesale-applications',
			'wam_msg' => $status,
			'uid'     => $user_id,
		],
		admin_url( 'admin.php' )
	);
}

// ---------------------------------------------------------------------------
// Approve handler
// ---------------------------------------------------------------------------

/**
 * Handle the "Approve" form submission.
 *
 * Changes the user role from wholesale_pending → wholesale_customer.
 * Hooked to: admin_post_approve_wholesale_user
 */
function wam_handle_approve_user(): void {

	// 1. Verify nonce.
	check_admin_referer( 'approve_wholesale_user', 'wam_nonce' );

	// 2. Capability check.
	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		wp_die(
			esc_html__( 'You do not have permission to perform this action.', 'wholesale-admin-manager' ),
			esc_html__( 'Forbidden', 'wholesale-admin-manager' ),
			[ 'response' => 403 ]
		);
	}

	// 3. Sanitize the user ID from POST.
	$user_id = isset( $_POST['user_id'] ) ? absint( $_POST['user_id'] ) : 0;

	if ( ! $user_id ) {
		wp_safe_redirect( wam_redirect_url( 'error', 0 ) );
		exit;
	}

	// 4. Fetch the user and validate role.
	$user = get_userdata( $user_id );

	if ( ! $user || ! in_array( 'wholesale_pending', (array) $user->roles, true ) ) {
		wp_safe_redirect( wam_redirect_url( 'error', $user_id ) );
		exit;
	}

	// 5. Promote the user.
	$user->set_role( 'wholesale_customer' );

	// 6. Record the approval date in user meta.
	update_user_meta( $user_id, 'wholesale_approved_date', current_time( 'mysql' ) );
	update_user_meta( $user_id, 'wholesale_approved_by',   get_current_user_id() );

	// 7. Future hook: allow extensions (email notifications, etc.) to run.
	do_action( 'wam_after_approve_user', $user_id );

	wp_safe_redirect( wam_redirect_url( 'approved', $user_id ) );
	exit;
}

// ---------------------------------------------------------------------------
// Reject handler
// ---------------------------------------------------------------------------

/**
 * Handle the "Reject" form submission.
 *
 * Converts the user role from wholesale_pending → customer (default WC role).
 * Hooked to: admin_post_reject_wholesale_user
 */
function wam_handle_reject_user(): void {

	// 1. Verify nonce.
	check_admin_referer( 'reject_wholesale_user', 'wam_nonce' );

	// 2. Capability check.
	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		wp_die(
			esc_html__( 'You do not have permission to perform this action.', 'wholesale-admin-manager' ),
			esc_html__( 'Forbidden', 'wholesale-admin-manager' ),
			[ 'response' => 403 ]
		);
	}

	// 3. Sanitize the user ID.
	$user_id = isset( $_POST['user_id'] ) ? absint( $_POST['user_id'] ) : 0;

	if ( ! $user_id ) {
		wp_safe_redirect( wam_redirect_url( 'error', 0 ) );
		exit;
	}

	// 4. Fetch user and validate role.
	$user = get_userdata( $user_id );

	if ( ! $user || ! in_array( 'wholesale_pending', (array) $user->roles, true ) ) {
		wp_safe_redirect( wam_redirect_url( 'error', $user_id ) );
		exit;
	}

	// 5. Downgrade to standard customer.
	$user->set_role( 'customer' );

	// 6. Record rejection metadata.
	update_user_meta( $user_id, 'wholesale_rejected_date', current_time( 'mysql' ) );
	update_user_meta( $user_id, 'wholesale_rejected_by',   get_current_user_id() );

	// 7. Future hook: allow extensions (email notifications, etc.) to run.
	do_action( 'wam_after_reject_user', $user_id );

	wp_safe_redirect( wam_redirect_url( 'rejected', $user_id ) );
	exit;
}
