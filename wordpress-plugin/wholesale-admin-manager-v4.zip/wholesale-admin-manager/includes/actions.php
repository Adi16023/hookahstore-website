<?php
/**
 * Action Handlers: Approve & Reject Wholesale Users
 *
 * These handlers listen on admin_post_ hooks registered in the main plugin file.
 * Both actions are protected with nonces and capability checks.
 *
 * @package WholesaleAdminManager
 */

defined( 'ABSPATH' ) || exit;

// ---------------------------------------------------------------------------
// Helper
// ---------------------------------------------------------------------------

/**
 * Build the redirect URL back to the Applications page, with an optional
 * admin-notice query argument.
 *
 * @param string $status  'approved' | 'rejected' | 'error'
 * @param int    $user_id The affected user ID (used for display / debugging).
 * @return string
 */
function wam_redirect_url( string $status, int $user_id = 0 ): string {
	return add_query_arg(
		[
			'page'    => 'wholesale-applications',
			'wam_msg' => $status,
			'uid'     => $user_id,
		],
		admin_url( 'admin.php' )
	);
}

// ---------------------------------------------------------------------------
// Webhook helper
// ---------------------------------------------------------------------------

/**
 * Notify the Next.js application that a wholesale account has been approved.
 *
 * Sends a POST request to /api/wholesale/approved so Next.js can dispatch
 * the approval confirmation email via Resend.
 *
 * The shared secret can be overridden in wp-config.php:
 *   define( 'WAM_WEBHOOK_SECRET', 'your_custom_secret' );
 *
 * It must match WHOLESALE_WEBHOOK_SECRET in the Next.js .env.local file.
 *
 * @param int    $user_id       WordPress user ID.
 * @param string $user_email    User's email address.
 * @param string $display_name  User's display name.
 */
function wam_send_approval_webhook( int $user_id, string $user_email, string $display_name ): void {
	$endpoint = 'https://thehookahstore.in/api/wholesale/approved';

	// Use wp-config constant if defined, otherwise fall back to the shared secret.
	$secret = defined( 'WAM_WEBHOOK_SECRET' )
		? WAM_WEBHOOK_SECRET
		: 'f8c1f301414b2c9c61260660f43f4a0246a4786b92aabb052548b502e1c96b65';

	$response = wp_remote_post(
		$endpoint,
		[
			'timeout'     => 10,
			'redirection' => 0,
			'headers'     => [
				'Content-Type'  => 'application/json',
				'Authorization' => 'Bearer ' . $secret,
			],
			'body'        => wp_json_encode(
				[
					'userId' => $user_id,
					'email'  => $user_email,
					'name'   => $display_name,
				]
			),
		]
	);

	if ( is_wp_error( $response ) ) {
		error_log(
			'[WAM] Approval webhook FAILED (network error) for user ' . $user_id
			. ': ' . $response->get_error_message()
		);
	} else {
		$status_code = wp_remote_retrieve_response_code( $response );
		if ( $status_code >= 200 && $status_code < 300 ) {
			error_log( '[WAM] Approval webhook OK (HTTP ' . $status_code . ') for user ' . $user_id );
		} else {
			error_log(
				'[WAM] Approval webhook returned HTTP ' . $status_code
				. ' for user ' . $user_id
				. ' — body: ' . wp_remote_retrieve_body( $response )
			);
		}
	}
}

// ---------------------------------------------------------------------------
// Approve handler
// ---------------------------------------------------------------------------

/**
 * Handle the "Approve" form submission.
 *
 * Changes the user role from wholesale_pending → wholesale_customer.
 * Hooked to: admin_post_approve_wholesale_user
 */
function wam_handle_approve_user(): void {

	// 1. Verify nonce.
	check_admin_referer( 'approve_wholesale_user', 'wam_nonce' );

	// 2. Capability check.
	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		wp_die(
			esc_html__( 'You do not have permission to perform this action.', 'wholesale-admin-manager' ),
			esc_html__( 'Forbidden', 'wholesale-admin-manager' ),
			[ 'response' => 403 ]
		);
	}

	// 3. Sanitize the user ID from POST.
	$user_id = isset( $_POST['user_id'] ) ? absint( $_POST['user_id'] ) : 0;

	if ( ! $user_id ) {
		wp_safe_redirect( wam_redirect_url( 'error', 0 ) );
		exit;
	}

	// 4. Fetch the user and validate role.
	$user = get_userdata( $user_id );

	if ( ! $user || ! in_array( 'wholesale_pending', (array) $user->roles, true ) ) {
		wp_safe_redirect( wam_redirect_url( 'error', $user_id ) );
		exit;
	}

	// 5. Promote the user.
	$user->set_role( 'wholesale_customer' );

	// 6. Notify Next.js to send the approval email.
	wam_send_approval_webhook( $user_id, $user->user_email, $user->display_name );

	// 7. Record the approval date in user meta.
	update_user_meta( $user_id, 'wholesale_approved_date', current_time( 'mysql' ) );
	update_user_meta( $user_id, 'wholesale_approved_by',   get_current_user_id() );

	// 8. Future hook: allow extensions (email notifications, etc.) to run.
	do_action( 'wam_after_approve_user', $user_id );

	wp_safe_redirect( wam_redirect_url( 'approved', $user_id ) );
	exit;
}

// ---------------------------------------------------------------------------
// Reject handler
// ---------------------------------------------------------------------------

/**
 * Handle the "Reject" form submission.
 *
 * Converts the user role from wholesale_pending → customer (default WC role).
 * Hooked to: admin_post_reject_wholesale_user
 */
function wam_handle_reject_user(): void {

	// 1. Verify nonce.
	check_admin_referer( 'reject_wholesale_user', 'wam_nonce' );

	// 2. Capability check.
	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		wp_die(
			esc_html__( 'You do not have permission to perform this action.', 'wholesale-admin-manager' ),
			esc_html__( 'Forbidden', 'wholesale-admin-manager' ),
			[ 'response' => 403 ]
		);
	}

	// 3. Sanitize the user ID.
	$user_id = isset( $_POST['user_id'] ) ? absint( $_POST['user_id'] ) : 0;

	if ( ! $user_id ) {
		wp_safe_redirect( wam_redirect_url( 'error', 0 ) );
		exit;
	}

	// 4. Fetch user and validate role.
	$user = get_userdata( $user_id );

	if ( ! $user || ! in_array( 'wholesale_pending', (array) $user->roles, true ) ) {
		wp_safe_redirect( wam_redirect_url( 'error', $user_id ) );
		exit;
	}

	// 5. Downgrade to standard customer.
	$user->set_role( 'customer' );

	// 6. Notify Next.js to send the rejection email.
	error_log( '[WAM] Rejection webhook triggered for user ' . $user_id );

	$secret = defined( 'WAM_WEBHOOK_SECRET' )
		? WAM_WEBHOOK_SECRET
		: 'f8c1f301414b2c9c61260660f43f4a0246a4786b92aabb052548b502e1c96b65';

	$reject_response = wp_remote_post(
		'https://thehookahstore.in/api/wholesale/rejected',
		[
			'timeout'     => 10,
			'redirection' => 0,
			'headers'     => [
				'Content-Type'  => 'application/json',
				'Authorization' => 'Bearer ' . $secret,
			],
			'body'        => wp_json_encode(
				[
					'userId' => $user_id,
					'email'  => $user->user_email,
					'name'   => $user->display_name,
				]
			),
		]
	);

	if ( is_wp_error( $reject_response ) ) {
		error_log( '[WAM] Rejection webhook FAILED: ' . $reject_response->get_error_message() );
	} else {
		error_log( '[WAM] Rejection webhook response: ' . wp_remote_retrieve_body( $reject_response ) );
	}

	// 7. Record rejection metadata.
	update_user_meta( $user_id, 'wholesale_rejected_date', current_time( 'mysql' ) );
	update_user_meta( $user_id, 'wholesale_rejected_by',   get_current_user_id() );

	// 8. Future hook: allow extensions (email notifications, etc.) to run.
	do_action( 'wam_after_reject_user', $user_id );

	wp_safe_redirect( wam_redirect_url( 'rejected', $user_id ) );
	exit;
}
